package com.example.asm_yenphph34781_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.asm_yenphph34781_android.Adapter.ClothesAdapter;
import com.example.asm_yenphph34781_android.databinding.ActivityHomeBinding;
import com.example.asm_yenphph34781_android.model.Clothes;
import com.example.asm_yenphph34781_android.server.HttpRequest;
import com.example.asm_yenphph34781_android.server.Response;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;

public class HomeActivity extends AppCompatActivity implements ClothesAdapter.ClothesClick{
ActivityHomeBinding binding;
private HttpRequest httpRequest;
private ClothesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
      binding = ActivityHomeBinding.inflate(getLayoutInflater());
      super.onCreate(savedInstanceState);
      setContentView(binding.getRoot());
       httpRequest = new HttpRequest();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.rcvclothes.setLayoutManager(layoutManager);
        addClothes();
    }
    public  void addClothes(){
binding.add.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(HomeActivity.this, AddClothesActivity.class));
    }
});
    }
//Retrofit2, modle
   Callback<Response<ArrayList<Clothes>>> getListFruitResponse = new Callback<Response<ArrayList<Clothes>>>() {
    @Override
    public void onResponse(Call<Response<ArrayList<Clothes>>> call, retrofit2.Response<Response<ArrayList<Clothes>>> response) {
        if(response.isSuccessful()){
            if(response.body().getStatus() == 200){
                ArrayList<Clothes> ds = response.body().getData();
                getData(ds);
            }
        }
    }

    @Override
    public void onFailure(Call<Response<ArrayList<Clothes>>> call, Throwable t) {

    }
};
    private void getData(ArrayList<Clothes> list){
        adapter = new ClothesAdapter(this, list, this);
        binding.rcvclothes.setAdapter(adapter);
    }

    @Override
    public void delete(Clothes clothes) {

    }

    @Override
    public void edit(Clothes clothes) {

    }

    @Override
    public void deleteItem(int position) {
        // Xóa mục từ danh sách dữ liệu
        Clothes deletedClothes = adapter.getList().remove(position);
        // Thông báo cho adapter biết dữ liệu đã thay đổi
        adapter.notifyItemRemoved(position);

        // Gọi API để xóa dữ liệu trên máy chủ
        if (deletedClothes != null) {
            httpRequest.callApi().deleteClothes(deletedClothes.get_id()).enqueue(new Callback<Response<Clothes>>() {
                @Override
                public void onResponse(Call<Response<Clothes>> call, retrofit2.Response<Response<Clothes>> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 200) {
                            // Xóa thành công trên máy chủ
                            // Có thể thực hiện các xử lý phụ trợ nếu cần
                        }
                    } else {
                        // Xử lý lỗi khi xóa trên máy chủ thất bại
                        Log.e("deleteClothes", "Failed to delete clothes on server");
                    }
                }

                @Override
                public void onFailure(Call<Response<Clothes>> call, Throwable t) {
                    // Xử lý lỗi khi gọi API xóa thất bại
                    Log.e("deleteClothes", "Failed to delete clothes: " + t.getMessage());
                }
            });
        }
    }
    @Override
    protected void onResume(){
        super.onResume();
        httpRequest.callApi().getListClothes().enqueue(getListFruitResponse);
    }
}