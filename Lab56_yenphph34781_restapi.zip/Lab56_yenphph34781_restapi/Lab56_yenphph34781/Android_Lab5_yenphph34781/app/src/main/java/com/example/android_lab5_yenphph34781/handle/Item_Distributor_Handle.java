package com.example.android_lab5_yenphph34781.handle;

import com.example.android_lab5_yenphph34781.model.Distributor;

public interface Item_Distributor_Handle {
    void onDelete(String id);
    public void Update(String id, Distributor distributor);
}
